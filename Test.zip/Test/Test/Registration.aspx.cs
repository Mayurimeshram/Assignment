﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace Test
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        static string str = "data source=.\\SQLEXPRESS01; integrated security=true; database=Test";
        SqlConnection con = new SqlConnection(str);
        SqlCommand command;
        string qr;

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                qr = "insert into Employee2(FirstName,LastName,Dateofbirth,Email,Password) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')";
                command = new SqlCommand(qr, con);
                con.Open();

                command.ExecuteNonQuery();
                Label1.Text = "Register Successfully";
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox1.Focus();
            }
            catch(Exception ee)
            {
                Label1.Text = ee.ToString();
            }
            finally
            {
                con.Close();
            }
            
        }
    }
}