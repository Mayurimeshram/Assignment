﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
namespace Test
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        static string str = "data source=.\\SQLEXPRESS01; integrated security=true; database=Test";
        SqlConnection con = new SqlConnection(str);
        SqlCommand command;
        string qr;

        protected void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                qr = "select count(*) From Employee2 where FirstName='" + TextBox1.Text + "' And Password='" + TextBox2.Text + "'";
                command = new SqlCommand(qr, con);
                con.Open();
                int res = Convert.ToInt32(command.ExecuteScalar());
                if (res == 0)
                {
                    Label1.Text = "invalid Information .....Try Again";
                }
                else
                {
                    string qr1 = "select FirstName,Dateofbirth From Employee2 where FirstName='" + TextBox1.Text + "' And Password='" + TextBox2.Text + "'";
                    SqlCommand command1 = new SqlCommand(qr1, con);
                    SqlDataReader dr = command1.ExecuteReader();
                    while (dr.Read())
                    {
                        string fn = dr["FirstName"].ToString();
                        string dob = dr["Dateofbirth"].ToString();
                        Response.Write("name" + fn);
                        Response.Write("dob " + dob);
                        string d = dob.Substring(6, 4);

                        int dd = Convert.ToInt32(d);
                        int ddd = DateTime.Now.Year - dd;
                        Response.Write("age " + ddd);
                        Session["uname"] = fn;
                        Session["age"] = ddd;

                    }
                    Response.Redirect("Welcome.aspx");
                }
            }

            catch (Exception ee)
            {
                Label1.Text = ee.ToString();
            }
            finally
            {
                con.Close();
            }


        }



    }
}


    

